Java Questionnaire — Android Studio

Features:
- Name field with autocomplete suggestions
- Gender radio buttons
- City radio buttons: Wrocław, Katowice, Warszawa, Ujazd
- Animal radio buttons: Kot, Pies
- Summary screen and navigation

Open:
1. Extract this ZIP.
2. In Android Studio choose File > Open.
3. Select the extracted JavaQuestionnaire folder.
4. Wait for Gradle sync to finish.
5. Run the app on an emulator or connected Android device.

Notes:
- This is an Android Studio source project, not a directly installable APK.
- Android Studio may download Gradle and Android SDK components on first open.
- Package name: com.example.kwestionariusz
