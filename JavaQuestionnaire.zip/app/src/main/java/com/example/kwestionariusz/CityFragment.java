package com.example.kwestionariusz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class CityFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity a = (MainActivity) requireActivity();
        RadioGroup group = Ui.radioGroup(requireContext());
        String[] cities = {"Wrocław", "Katowice", "Warszawa", "Ujazd"};
        for (String city : cities) {
            RadioButton radio = Ui.radio(requireContext(), city);
            group.addView(radio);
            if (a.miasto.equals(city)) radio.setChecked(true);
        }

        android.widget.LinearLayout layout = Ui.column(requireContext());
        layout.addView(Ui.title(requireContext(), "3. Wybierz miasto"));
        layout.addView(group);
        Button back = Ui.button(requireContext(), "Wstecz");
        Button next = Ui.button(requireContext(), "Dalej");
        layout.addView(back);
        layout.addView(next);
        back.setOnClickListener(v -> a.pokazFragment(new GenderFragment()));
        next.setOnClickListener(v -> {
            int id = group.getCheckedRadioButtonId();
            if (id == -1) {
                Toast.makeText(requireContext(), "Wybierz miasto", Toast.LENGTH_SHORT).show();
                return;
            }
            RadioButton selected = group.findViewById(id);
            a.miasto = selected.getText().toString();
            a.pokazFragment(new AnimalFragment());
        });
        return layout;
    }
}
