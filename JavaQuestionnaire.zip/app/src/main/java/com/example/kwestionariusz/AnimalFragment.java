package com.example.kwestionariusz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class AnimalFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity a = (MainActivity) requireActivity();
        RadioGroup group = Ui.radioGroup(requireContext());
        RadioButton cat = Ui.radio(requireContext(), "Kot");
        RadioButton dog = Ui.radio(requireContext(), "Pies");
        group.addView(cat);
        group.addView(dog);
        if (a.zwierze.equals("Kot")) cat.setChecked(true);
        if (a.zwierze.equals("Pies")) dog.setChecked(true);

        android.widget.LinearLayout layout = Ui.column(requireContext());
        layout.addView(Ui.title(requireContext(), "4. Wybierz zwierzę"));
        layout.addView(group);
        Button back = Ui.button(requireContext(), "Wstecz");
        Button next = Ui.button(requireContext(), "Zatwierdź");
        layout.addView(back);
        layout.addView(next);
        back.setOnClickListener(v -> a.pokazFragment(new CityFragment()));
        next.setOnClickListener(v -> {
            int id = group.getCheckedRadioButtonId();
            if (id == cat.getId()) a.zwierze = "Kot";
            else if (id == dog.getId()) a.zwierze = "Pies";
            else {
                Toast.makeText(requireContext(), "Wybierz zwierzę", Toast.LENGTH_SHORT).show();
                return;
            }
            a.pokazFragment(new SummaryFragment());
        });
        return layout;
    }
}
