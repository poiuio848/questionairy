package com.example.kwestionariusz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class NameFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity a = (MainActivity) requireActivity();
        LinearLayout layout = Ui.column(requireContext());

        layout.addView(Ui.title(requireContext(), "1. Podaj imię"));

        AutoCompleteTextView name = new AutoCompleteTextView(requireContext());
        name.setHint("Wpisz imię");
        name.setThreshold(1);
        name.setSingleLine(true);
        name.setText(a.imie);
        String[] names = {"Kasia", "Karolina", "Kamil", "Kacper", "Anna", "Adam", "Julia", "Jan"};
        name.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, names));
        layout.addView(name, Ui.params());

        Button next = Ui.button(requireContext(), "Dalej");
        layout.addView(next);
        next.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isEmpty()) {
                name.setError("Wpisz imię");
                return;
            }
            a.imie = value;
            a.pokazFragment(new GenderFragment());
        });
        return layout;
    }
}
