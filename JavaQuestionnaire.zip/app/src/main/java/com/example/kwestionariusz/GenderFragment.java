package com.example.kwestionariusz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.view.View;
import androidx.fragment.app.Fragment;

public class GenderFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity a = (MainActivity) requireActivity();
        RadioGroup group = Ui.radioGroup(requireContext());
        RadioButton male = Ui.radio(requireContext(), "Mężczyzna");
        RadioButton female = Ui.radio(requireContext(), "Kobieta");
        group.addView(male);
        group.addView(female);
        if (a.plec.equals("Mężczyzna")) male.setChecked(true);
        if (a.plec.equals("Kobieta")) female.setChecked(true);

        android.widget.LinearLayout layout = Ui.column(requireContext());
        layout.addView(Ui.title(requireContext(), "2. Wybierz płeć"));
        layout.addView(group);
        Button back = Ui.button(requireContext(), "Wstecz");
        Button next = Ui.button(requireContext(), "Dalej");
        layout.addView(back);
        layout.addView(next);
        back.setOnClickListener(v -> a.pokazFragment(new NameFragment()));
        next.setOnClickListener(v -> {
            int id = group.getCheckedRadioButtonId();
            if (id == male.getId()) a.plec = "Mężczyzna";
            else if (id == female.getId()) a.plec = "Kobieta";
            else {
                Toast.makeText(requireContext(), "Wybierz płeć", Toast.LENGTH_SHORT).show();
                return;
            }
            a.pokazFragment(new CityFragment());
        });
        return layout;
    }
}
