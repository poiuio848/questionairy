package com.example.kwestionariusz;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

final class Ui {
    private Ui() {}

    static LinearLayout column(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * context.getResources().getDisplayMetrics().density);
        layout.setPadding(p, p, p, p);
        return layout;
    }

    static TextView title(Context context, String text) {
        TextView title = new TextView(context);
        title.setText(text);
        title.setTextSize(26);
        title.setPadding(0, 0, 0, 20);
        return title;
    }

    static Button button(Context context, String text) {
        Button button = new Button(context);
        button.setText(text);
        return button;
    }

    static RadioGroup radioGroup(Context context) {
        RadioGroup group = new RadioGroup(context);
        group.setOrientation(RadioGroup.VERTICAL);
        return group;
    }

    static RadioButton radio(Context context, String text) {
        RadioButton radio = new RadioButton(context);
        radio.setText(text);
        radio.setId(View.generateViewId());
        return radio;
    }

    static LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
