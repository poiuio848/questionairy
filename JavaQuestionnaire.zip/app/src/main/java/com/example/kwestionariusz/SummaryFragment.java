package com.example.kwestionariusz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class SummaryFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MainActivity a = (MainActivity) requireActivity();
        android.widget.LinearLayout layout = Ui.column(requireContext());
        layout.addView(Ui.title(requireContext(), "Podsumowanie kwestionariusza"));

        TextView result = new TextView(requireContext());
        result.setText("Imię: " + a.imie
                + "\n\nPłeć: " + a.plec
                + "\n\nMiasto: " + a.miasto
                + "\n\nUlubione zwierzę: " + a.zwierze);
        result.setTextSize(20);
        layout.addView(result);

        Button back = Ui.button(requireContext(), "Wstecz");
        Button finish = Ui.button(requireContext(), "Zakończ");
        layout.addView(back);
        layout.addView(finish);
        back.setOnClickListener(v -> a.pokazFragment(new AnimalFragment()));
        finish.setOnClickListener(v -> {
            a.imie = "";
            a.plec = "";
            a.miasto = "";
            a.zwierze = "";
            a.pokazFragment(new NameFragment());
        });
        return layout;
    }
}
